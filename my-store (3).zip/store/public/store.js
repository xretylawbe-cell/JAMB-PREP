const $=(s)=>document.querySelector(s);
const api=(p,o={})=>fetch('/api'+p,{...o,headers:{'Content-Type':'application/json','x-requested-with':'fetch'},body:o.body&&JSON.stringify(o.body)}).then(async r=>{const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d.error||'Something went wrong. Please try again.');return d});
const money=n=>'₦'+Number(n).toLocaleString();
const el=(t,a={},...k)=>{const e=document.createElement(t);for(const[x,v]of Object.entries(a))x=='class'?e.className=v:x.startsWith('on')?e[x]=v:e.setAttribute(x,v);e.append(...k.filter(c=>c!=null&&c!==false));return e};
const Cart={get(){try{return JSON.parse(localStorage.getItem('cart')||'[]')}catch{return[]}},set(c){try{localStorage.setItem('cart',JSON.stringify(c))}catch{}document.querySelectorAll('.cb').forEach(b=>b.textContent=this.count())},add(i){const c=this.get(),x=c.find(y=>y.key==i.key);x?x.qty+=i.qty:c.push(i);this.set(c)},count(){return this.get().reduce((s,i)=>s+i.qty,0)}};
const grid=ps=>ps.length?el('div',{class:'grid'},...ps.map(p=>el('a',{class:'card',href:'/product.html?id='+p.id},el('img',{src:p.image_url||'',alt:p.name,loading:'lazy'}),el('b',{},p.name),el('span',{},money(p.retail_price)),p.stock<1?el('small',{}, ' Sold out'):null))):el('p',{},'No products found.');
async function boot(page){
  let S={};try{S=await api('/settings')}catch{}
  const name=S.store_name||'Store',q=new URLSearchParams(location.search).get('q')||'';
  document.title=name+(document.title&&document.title!=name?' – '+document.title:'');
  const links=[['Home','/'],['Shop','/shop.html'],['Cart','/cart.html'],['Account','/account.html']];
  const cb=()=>el('span',{class:'cb'},String(Cart.count()));
  const search=el('form',{action:'/shop.html'},el('input',{name:'q',value:q,placeholder:'Search products','aria-label':'Search products'}));
  const top=el('header',{class:'top'},el('div',{class:'row'},el('a',{class:'logo',href:'/'},name),search,el('nav',{class:'d'},...links.map(([t,h])=>el('a',{href:h},t,t=='Cart'?' (':null,t=='Cart'?cb():null,t=='Cart'?')':null)))));
  const mob=el('nav',{class:'m'},...links.map(([t,h])=>el('a',{href:h},t,t=='Cart'?' (':null,t=='Cart'?cb():null,t=='Cart'?')':null)));
  const pages=[['About','about'],['Contact','contact'],['Delivery','delivery_info'],['Policies','policies']].filter(([,k])=>S[k]);
  const foot=el('footer',{},...pages.map(([t,k])=>el('a',{href:'/page.html?p='+k},t)),...['facebook','instagram','tiktok'].filter(k=>S['social_'+k]).map(k=>el('a',{href:S['social_'+k],rel:'noopener'},k[0].toUpperCase()+k.slice(1))),el('p',{class:'pre'},S.footer||'© '+name));
  const main=el('main',{class:'wrap',id:'main'});
  document.body.prepend(...[S.promo_message?el('div',{id:'promo'},S.promo_message):null,top].filter(Boolean));
  document.body.append(main,foot,mob);
  await page(S,main);
}
