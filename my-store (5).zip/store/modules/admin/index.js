exports.name = 'admin';
exports.mount = (app, { db, auth }) => {
  const A = auth.requireAdmin;
  app.get('/api/admin/customers', A, async (_q, res) => res.json(await db.query('SELECT id,name,email,phone,wholesale_approved,created_at FROM customers ORDER BY id DESC LIMIT 500')));
  app.put('/api/admin/customers/:id/wholesale', A, async (req, res) => { await db.query('UPDATE customers SET wholesale_approved=? WHERE id=?', [req.body.approved ? 1 : 0, req.params.id]); res.json({ ok: true }); });
  app.get('/api/admin/orders/:id', A, async (req, res) => {
    const [order] = await db.query('SELECT * FROM orders WHERE id=?', [req.params.id]); if (!order) return res.status(404).json({ error: 'Order not found' });
    res.json({ order, items: await db.query('SELECT name,qty,unit_price FROM order_items WHERE order_id=?', [req.params.id]) });
  });
  app.get('/api/admin/inventory', A, async (_q, res) => res.json({
    products: await db.query('SELECT id,name,sku,stock,status FROM products ORDER BY stock ASC, id DESC'),
    variants: await db.query('SELECT v.id,v.label,v.stock,p.name product FROM variants v JOIN products p ON p.id=v.product_id ORDER BY v.stock ASC'),
  }));
  app.put('/api/admin/stock', A, async (req, res) => {
    const { type, id } = req.body, stock = Number(req.body.stock);
    if (!['product', 'variant'].includes(type) || !Number.isInteger(stock) || stock < 0) return res.status(400).json({ error: 'Stock must be a whole number, 0 or more' });
    await db.query(`UPDATE ${type === 'product' ? 'products' : 'variants'} SET stock=? WHERE id=?`, [stock, id]); res.json({ ok: true });
  });
};
