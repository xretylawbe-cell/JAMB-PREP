const test = require('node:test'), assert = require('node:assert');
const { validateLayout } = require('../modules/settings/layout');
const ok = (a) => validateLayout(JSON.stringify(a));
test('valid layout is normalised', () => assert.deepEqual(JSON.parse(ok([{ type: 'hero', settings: { heading: ' Hi ', junk: 'x', button_link: '/shop.html' } }]).value), [{ type: 'hero', settings: { heading: 'Hi', button_link: '/shop.html' } }]));
test('unknown type rejected', () => assert.match(ok([{ type: 'script' }]).error, /Unknown/));
test('javascript and protocol-relative links rejected', () => { assert.ok(ok([{ type: 'hero', settings: { button_link: 'javascript:alert(1)' } }]).error); assert.ok(ok([{ type: 'hero', settings: { button_link: '//evil.com' } }]).error); });
test('http images rejected, uploads allowed', () => { assert.ok(ok([{ type: 'hero', settings: { image: 'http://x.com/a.png' } }]).error); assert.ok(!ok([{ type: 'hero', settings: { image: '/uploads/a.png' } }]).error); });
test('too many sections rejected', () => assert.ok(ok(Array(31).fill({ type: 'rich_text' })).error));
