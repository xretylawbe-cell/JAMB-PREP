// Homepage sections ("blocks"). Single source of truth: the admin editor reads this schema from the API.
const H = ['Heading', 'text'], TX = ['Text', 'long'], IMG = ['Image URL', 'url'], BT = ['Button text', 'text'], BL = ['Button link (e.g. /shop.html)', 'link'], CT = ['Products to show (1-12)', 'num'];
const TYPES = {
  announcement: { label: 'Announcement bar', fields: { text: ['Message', 'text'] } },
  hero: { label: 'Hero banner', fields: { heading: H, text: TX, image: IMG, button_text: BT, button_link: BL } },
  categories: { label: 'Category shortcuts', fields: { heading: H } },
  collection: { label: 'Collection products', fields: { heading: H, collection_id: ['Collection ID (see list below)', 'num'], count: CT } },
  products: { label: 'Latest products', fields: { heading: H, count: CT } },
  image_text: { label: 'Image with text', fields: { heading: H, text: TX, image: IMG, button_text: BT, button_link: BL } },
  rich_text: { label: 'Text block', fields: { heading: H, text: TX } },
  whatsapp: { label: 'WhatsApp call-to-action', fields: { heading: H, text: TX } },
};
const RULE = { text: (v) => v.length <= 200, long: (v) => v.length <= 2000, url: (v) => v.length <= 500 && /^(https:\/\/|\/uploads\/)/.test(v), link: (v) => v.length <= 500 && /^(\/(?!\/)|https:\/\/)/.test(v), num: (v) => /^\d{1,7}$/.test(v) };
function validateLayout(raw) {
  let arr; try { arr = JSON.parse(raw); } catch { return { error: 'Layout is not valid JSON' }; }
  if (!Array.isArray(arr) || arr.length > 30) return { error: 'A layout can have at most 30 sections' };
  const out = [];
  for (const s of arr) {
    const t = TYPES[s?.type]; if (!t) return { error: `Unknown section type: ${s?.type}` };
    const settings = {};
    for (const [f, [label, kind]] of Object.entries(t.fields)) {
      const v = String(s.settings?.[f] ?? '').trim(); if (!v) continue;
      if (!RULE[kind](v)) return { error: `${t.label} – "${label}" is not valid` };
      settings[f] = v;
    }
    out.push({ type: s.type, settings });
  }
  return { value: JSON.stringify(out) };
}
module.exports = { TYPES, validateLayout };
